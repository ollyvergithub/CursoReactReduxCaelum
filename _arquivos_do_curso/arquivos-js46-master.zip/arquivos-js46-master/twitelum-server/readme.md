# Como usar?

- A API utilizada durante o curso se encontra neste repositório: https://github.com/omariosouto/twitelum-api, caso você queira usá-la localmente, basta:
> Clonar o projeto
> Acessar a pasta e rodar um `npm install`
> E depois de tudo rodar o comando `npm start`

- Você pode utilizar a versão online da API através da url: https://twitelum-api.herokuapp.com/
